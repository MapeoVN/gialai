# mapeo-default-config

This is the default config (categories, icons and questions) used by Mapeo for data collection. Users can override this with their own config with custom categories, icons and questions.
